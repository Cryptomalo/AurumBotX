class MemeCoinHunter:
    pass
