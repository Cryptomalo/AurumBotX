class YahooFinanceProvider:
    def get_real_time_price(self, symbol):
        return None

